//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BP_v1.rc
//
#define IDD_BP_V1_DIALOG                102
#define IDR_MAINFRAME                   128
#define IDC_TAB1                        1000
#define IDC_RADIO_FILTER_RCOS           1010
#define IDC_RADIO_FILTER_BIKUBE         1011
#define IDC_RADIO_FILTER_BILINE         1012
#define IDC_RADIO_FILTER_NOT            1013
#define IDC_BOT_FIND_HOT_FRMAE          1014
#define IDC_BOT_FIND_COOL_FRMAE         1015
#define IDC_BUT_FIND_IN_2_FRAME         1016
#define IDC_BUT_FIND_IN_1_FRAME         1017
#define IDC_SLIDER1                     1018
#define IDC_BOT_RESET_LIST_POINTS       1019
#define IDC_BOT_LIST_OF_POINTS_REPORT   1020
#define IDC_BOT_ADD_POINT_UNDER_KREST   1021
#define IDC_BOT_READ_FROM_FLASH         1022
#define IDC_RADIO_N2_N2                 1023
#define IDC_RADIO_N1_N2                 1024
#define IDC_RADIO_0_N2                  1025
#define IDC_RADIO_P1_N2                 1026
#define IDC_RADIO_P2_N2                 1027
#define IDC_RADIO_N2_N1                 1028
#define IDC_RADIO_N1_N1                 1029
#define IDC_RADIO_0_N1                  1030
#define IDC_RADIO_P1_N1                 1031
#define IDC_RADIO_P2_N1                 1032
#define IDC_RADIO_N2_0                  1033
#define IDC_RADIO_N1_0                  1034
#define IDC_RADIO_0_0                   1035
#define IDC_RADIO_P1_0                  1036
#define IDC_RADIO_P2_0                  1037
#define IDC_RADIO_N2_P1                 1038
#define IDC_RADIO_N1_P1                 1039
#define IDC_RADIO_0_P1                  1040
#define IDC_RADIO_P1_P1                 1041
#define IDC_RADIO_P2_P1                 1042
#define IDC_RADIO_N2_P2                 1043
#define IDC_RADIO_N1_P2                 1044
#define IDC_RADIO_0_P2                  1045
#define IDC_RADIO_P1_P2                 1046
#define IDC_RADIO_P2_P2                 1047
#define IDC_STATIC_SCALE                1048
#define IDC_STATIC_LIST_OF_BP           1049
#define IDC_STATIC_FILTER_RES           1050
#define IDC_STATIC_AUTO_FIND            1051
#define IDC_STATIC_FIND_IN_2_FRAME      1052
#define IDC_STATIC_FIND_IN_1_FRAME      1053
#define IDC_STATIC_POINT_TO_CHANGE      1054
#define IDC_STATIC_KREST_CONTROL        1055
#define IDC_STATIC_KREST_COLOR          1056
#define IDC_BOT_SAVE_TO_FLASH2          1057
#define IDC_BOT_DEL_POINT_UNDER_KREST   1058
#define IDC_RADIO_M11                   1059
#define IDC_RADIO_M12                   1060
#define IDC_RADIO_M13                   1061
#define IDC_RADIO_M14                   1062
#define IDC_RADIO_M15                   1063
#define IDC_RADIO_M16                   1064
#define IDC_BUT_DRIVE_KREST_N           1065
#define IDC_BUT_DRIVE_KREST_NE          1066
#define IDC_BUT_DRIVE_KREST_W           1067
#define IDC_BUT_DRIVE_KREST_CENTR       1068
#define IDC_BUT_DRIVE_KREST_E           1069
#define IDC_BUT_DRIVE_KREST_SW          1070
#define IDC_BUT_DRIVE_KREST_S           1071
#define IDC_BUT_DRIVE_KREST_SE          1072
#define IDC_RADIO_X1                    1073
#define IDC_RADIO_X3                    1074
#define IDC_RADIO_X10                   1075
#define IDC_RADIO_X100                  1076
#define IDC_BUT_AREA_KREST              1077
#define IDC_BUT_AREA_CENTER             1078
#define IDC_LIST_TERMINAL               1079
#define IDC_EDIT_CMD                    1080
#define IDC_BUT_ENTER                   1081
#define IDC_STATIC_CHOOSE_ARIA          1082
#define IDC_BUT_DRIVE_KREST_NW          1083
#define IDC_CHECK_STOP_KADR             1084
#define IDC_CHECK_VKL_KRESTA            1085
#define IDC_STATIC_SCALE_DRIVE_KREST    1086
#define IDC_SPIN_FIND_IN_2_FRAME        1087
#define IDC_EDIT_FIND_IN_2_FRAME        1088
#define IDC_EDIT_FIND_IN_1_FRAME        1089
#define IDC_SPIN_FIND_IN_1_FRAME        1090
#define IDC_COMBO_COM                   1091
#define IDC_STATIC_COM_PORTS            1092
#define IDC_STATIC_BAUD_RATE            1093
#define IDC_BUTTON_CONNECT              1100
#define IDC_COMBO_SPEED                 1106
#define IDC_RADIO_CONNECT_INDICATOR     1110
#define IDC_STATIC_CONNECT_GROUP        1111
#define IDC_SLIDER2                     1112
#define IDC_STATIC_CONNECTION           1114

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1115
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
